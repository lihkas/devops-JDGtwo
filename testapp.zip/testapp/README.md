# Hook Landing Page Theme

This landing page theme is built on [shorthand css framework](https://github.com/shorthandcss/shorthand)

![preview](/preview.jpg)

## Credit

* Picture [unsplash](https://unsplash.com)
* Icons [feathericons](https://feathericons.com)

## LICENSE

The theme is available under the MIT License.